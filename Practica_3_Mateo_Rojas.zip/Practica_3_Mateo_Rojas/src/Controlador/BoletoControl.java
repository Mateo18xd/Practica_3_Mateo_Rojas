/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Controlador.TDA.Listas.ListaEnlazada;
import modelo.Boleto;
import modelo.Pasajero;
import modelo.Venta;

/**
 *
 * @author Usuario iTC 
 */
public class BoletoControl {
    private Boleto boleto;
    private Venta venta;
    private ListaEnlazada <Boleto> boletos ;

    
    public BoletoControl( ) {
        this.boletos = new ListaEnlazada<>();
        this.boleto= new Boleto();
    }
    
    public ListaEnlazada<Boleto> getBoletos() {
        return boletos;
    }
    
    public void setBoleto(ListaEnlazada<Boleto> boletos) {
        this.boletos = boletos;
    } 
    
    public Boolean guardar(){
        if(boleto !=null){
            boletos.add(boleto);
            return true;
        }
        return false;
    }
    
    public Boleto getBoleto() {
        if (boleto == null) {
            boleto = new Boleto();
        }
        return boleto;
    }
    
    public void setBoleto(Boleto boletos) {
        this.boleto = boletos;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }
  
}
