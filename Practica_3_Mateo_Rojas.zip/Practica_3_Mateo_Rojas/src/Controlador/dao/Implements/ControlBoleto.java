/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador.dao.Implements;

import Controlador.*;
import Controlador.TDA.Listas.Exception.EmptyException;
import Controlador.TDA.Listas.ListaEnlazada;
import Controlador.Validacion.Utiles;
import Controlador.dao.DaoImplements;
import java.lang.reflect.Field;
import modelo.Boleto;
import modelo.Pasajero;

/**
 *
 * @author Usuario iTC
 */
public class ControlBoleto extends DaoImplements<Boleto> {

    private ListaEnlazada<Boleto> boletos = new ListaEnlazada<>();
    private Boleto boleto = new Boleto();

    public ControlBoleto() {
        super(Boleto.class);
    }

    public ControlBoleto(Boleto boleto, Class<Boleto> clazz) {
        super(clazz);
        this.boleto = boleto;
    }
    public ListaEnlazada<Boleto> getBoletos() {
        if (boletos.isEmpty()) {
            boletos = this.all();
        }
        return boletos;
    }

    public void setBoletos(ListaEnlazada<Boleto> boletos) {
        this.boletos = boletos;
    }

    public Boleto getBoleto() {
        if (boleto == null) {
            boleto = new Boleto();
        }
        return boleto;
    }

    public void setBoleto(Boleto boleto) {
        this.boleto = boleto;
    }

    public Boolean persist() {
        boleto.setId(all().getLength()+1);
        return persist(boleto);
    }

 
        public Double calcularTotal(Boleto boleto){
        Double total=0.0;
        total = boleto.getCantidad()* boleto.getValor();
        return total;
        
    } 

    
    public ListaEnlazada<Boleto> ordenarQuicksortB(ListaEnlazada<Boleto> lista, Integer tipo, String field) throws EmptyException, Exception {
        Boleto[] boletos = lista.toArray(); 

        Field attribute = Utiles.getField(Boleto.class, field); 
        if (attribute != null) { 
            quickSortB(boletos, 0, boletos.length - 1, tipo, field); 
        } else {
            throw new Exception("El criterio de búsqueda no existe"); 
        }

        return lista.toList(boletos); 
    }

    
    private void quickSortB(Boleto[] boletos, int izq, int der, Integer tipo, String field) {
        if (izq < der) { 
            int particionIndex = particion(boletos, izq, der, tipo, field);
            quickSortB(boletos, izq, particionIndex - 1, tipo, field); 
            quickSortB(boletos, particionIndex + 1, der, tipo, field); 
        }
    }

    
    private int particion(Boleto[] boletos, int izq, int der, Integer tipo, String field) {
        Boleto pivot = boletos[der]; 
        int i = izq - 1; 

        for (int j = izq; j < der; j++) { 
            if (boletos[j].compare(pivot, field, tipo)) { 
                i++; 
                Boleto temp = boletos[i];
                boletos[i] = boletos[j]; 
                boletos[j] = temp;
            }
        }

        Boleto temp = boletos[i + 1];
        boletos[i + 1] = boletos[der]; 
        boletos[der] = temp;

        return i + 1; 
    }


public ListaEnlazada<Boleto> shellSortOrden(ListaEnlazada<Boleto> lista, Integer tipo, String field) throws EmptyException, Exception {
    Field attribute = Utiles.getField(Boleto.class, field); 
    Boleto[] boletos = lista.toArray(); 

    if (attribute == null) {
        throw new Exception("El criterio de búsqueda no existe"); 
    }

    int N = boletos.length; 
    int salto = N / 2; 

    while (salto >= 1) { 
        for (int i = 0; i < salto; i++) { 
            for (int j = salto + i; j < N; j += salto) { 
                Boleto v = boletos[j]; 
                int n = j - salto; 

                
                while (n >= 0 && boletos[n].compare(v, field, tipo)) {
                    boletos[n + salto] = boletos[n];
                    n -= salto;
                }

                boletos[n + salto] = v; 
            }
        }
        salto /= 2; 
    }

    lista.limpiar(); 
    for (Boleto boleto : boletos) {
        lista.add(boleto); 
    }
    return lista.toList(boletos); 
}


    public static void main(String[] args) {
        ControlBoleto controlBoleto = new ControlBoleto();

        try {
            ListaEnlazada<Boleto> listaBoletos = controlBoleto.getBoletos();
            ListaEnlazada<Boleto> listaOrdenada = controlBoleto.shellSortOrden(listaBoletos, 0, "id");
            for (int i = 0; i < listaOrdenada.getLength(); i++) {
                Boleto boleto = listaOrdenada.getInfo(i);
                System.out.println("Nombre: " + boleto.getPasajero() + ", ID: " + boleto.getId());
            }
        } catch (EmptyException e) {
            e.printStackTrace(); 
        } catch (Exception ex) {
            ex.printStackTrace(); 
        }
    }
}
